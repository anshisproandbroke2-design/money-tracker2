package com.example.moneytracker

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

const val TYPE_IN = "in"
const val TYPE_OUT = "out"

@Entity(tableName = "entries")
data class Entry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,        // "in" (aaya) ya "out" (gaya)
    val amount: Double,
    val category: String,
    val note: String,
    val date: String         // yyyy-MM-dd
)

@Dao
interface EntryDao {
    @Query("SELECT * FROM entries ORDER BY date DESC, id DESC")
    fun all(): Flow<List<Entry>>

    @Insert
    suspend fun insert(entry: Entry)

    @Delete
    suspend fun delete(entry: Entry)
}

@Database(entities = [Entry::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): EntryDao

    companion object {
        @Volatile
        private var instance: AppDb? = null

        fun get(context: android.content.Context): AppDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDb::class.java,
                    "money.db"
                ).build().also { instance = it }
            }
    }
}
