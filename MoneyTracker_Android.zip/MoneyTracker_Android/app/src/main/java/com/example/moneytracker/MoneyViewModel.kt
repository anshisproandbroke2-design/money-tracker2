package com.example.moneytracker

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MoneyViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDb.get(app).dao()

    val entries: StateFlow<List<Entry>> = dao.all()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(entry: Entry) {
        viewModelScope.launch { dao.insert(entry) }
    }

    fun delete(entry: Entry) {
        viewModelScope.launch { dao.delete(entry) }
    }
}
