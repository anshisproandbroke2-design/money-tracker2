package com.example.moneytracker

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate
import java.util.Locale

val OUT_CATEGORIES = listOf("Khana", "Travel", "Shopping", "Bills", "Recharge", "Entertainment", "Other")
val IN_CATEGORIES = listOf("Salary", "Business", "Gift", "Other")

fun categoriesFor(type: String): List<String> =
    if (type == TYPE_IN) IN_CATEGORIES else OUT_CATEGORIES

fun categoryColor(category: String): Color = when (category) {
    "Khana" -> Color(0xFFF59E0B)
    "Travel" -> Color(0xFF3B82F6)
    "Shopping" -> Color(0xFFEC4899)
    "Bills" -> Color(0xFFEF4444)
    "Recharge" -> Color(0xFF8B5CF6)
    "Entertainment" -> Color(0xFF10B981)
    "Salary" -> Color(0xFF34D399)
    "Business" -> Color(0xFF22D3EE)
    "Gift" -> Color(0xFFA3E635)
    else -> Color(0xFF64748B)
}

fun fmt(value: Double): String {
    val v = Math.abs(value)
    return if (v % 1.0 == 0.0) {
        "₹" + String.format(Locale.US, "%,.0f", v)
    } else {
        "₹" + String.format(Locale.US, "%,.2f", v)
    }
}

fun fmtSigned(value: Double): String = (if (value < 0) "-" else "+") + fmt(value)

fun List<Entry>.income(): Double = filter { it.type == TYPE_IN }.sumOf { it.amount }
fun List<Entry>.expense(): Double = filter { it.type == TYPE_OUT }.sumOf { it.amount }

fun exportCsv(context: Context, entries: List<Entry>) {
    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, "money_${LocalDate.now()}.csv")

    val sb = StringBuilder("Date,Type,Category,Amount,Note\n")
    entries.sortedBy { it.date }.forEach { e ->
        val type = if (e.type == TYPE_IN) "Income" else "Expense"
        val note = e.note.replace("\"", "\"\"")
        sb.append("${e.date},$type,${e.category},${e.amount},\"$note\"\n")
    }
    file.writeText(sb.toString())

    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "CSV bhejein"))
}
